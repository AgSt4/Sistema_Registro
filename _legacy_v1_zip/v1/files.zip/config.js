// ============================================================
// CONFIGURACIÓN — edita estas 3 variables y guarda el archivo
// ============================================================

const SUPABASE_URL = "https://TU-PROYECTO.supabase.co";
const SUPABASE_ANON_KEY = "TU-ANON-KEY-AQUI";
const GOOGLE_CLIENT_ID = "TU-GOOGLE-CLIENT-ID.apps.googleusercontent.com";
